/*
    Chatroom: CS132 Project Implementation
    by Matt Patenaude
*/

// most of this is boilerplate from the handout
var express = require('express'),
    anyDB = require('any-db'),
    engines = require('consolidate'),
    fs = require('fs');

var app = express();
var conn = anyDB.createConnection('sqlite3://chatroom.db');

// do some configuration for templating and body parsing
app.use(express.bodyParser());
app.engine('html', engines.hogan);
app.set('views', __dirname + '/templates');

// expose a few static directories
app.use('/public', express.static(__dirname + '/public'));
app.use('/public/messages', express.static('/Applications/Messages.app/Contents/Resources'));

// utility functions
function generateRoomIdentifier() {
    // make a list of legal characters
    // we're intentionally excluding 0, O, I, and 1 for readability
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    var result = '';
    for (var i = 0; i < 6; i++)
        result += chars.charAt(Math.floor(Math.random() * chars.length));

    return result;
}

// setup our home page
app.get('/', function(req, res){
    var rooms = [];
    var q = conn.query("SELECT DISTINCT room FROM messages WHERE time >= strftime('%s','now', '-5 minutes') ORDER BY time DESC");
    q.on('row', function(row){
        rooms.push(row);
    });
    q.on('end', function(){
        res.render('index.html', {activeRooms: rooms});
    });
});
app.get('/newRoom', function(req, res){
    res.redirect('/' + generateRoomIdentifier());
});

// provide a landing page for each chatroom
app.get('/:roomName', function(req, res){
    res.render('room.html', {roomName: req.params.roomName});
});

// attach handlers for posting and fetching message lists
app.get('/:roomName/messages', function(req, res){
    var messages = [];
    var q = conn.query("SELECT * FROM messages WHERE room = $1 ORDER BY id ASC", [req.params.roomName]);
    q.on('row', function(row){
        messages.push(row);
    });
    q.on('end', function(){
        res.json(messages);
    });
});
app.get('/:roomName/messages/since/:sinceID', function(req, res){
    var messages = [];
    var q = conn.query("SELECT * FROM messages WHERE room = $1 AND id > $2 ORDER BY id ASC", [req.params.roomName, req.params.sinceID]);
    q.on('row', function(row){
        messages.push(row);
    });
    q.on('end', function(){
        res.json(messages);
    });
});
app.post('/:roomName/messages', function(req, res){
    var rowID = null;
    var tx = conn.begin();  // start a transaction so we can get the insert ID
    
    tx.query("INSERT INTO messages (room, nickname, body, time) VALUES ($1, $2, $3, strftime('%s', 'now'))", [req.params.roomName, req.body.nickname, req.body.message]);
    tx.query("SELECT last_insert_rowid() AS id", function(err, res){
        rowID = res.rows[0].id;
    });
    
    tx.commit(function(){
        res.type('text');
        res.send('' + rowID);   // send as a string
    });
});

// perform database whoosiwhatsits, then start listening
console.log('- Preparing database...');

// here, we cheat and use a sqlite3 method (exec) that lets us run multiple queries at once
var schema = fs.readFileSync(__dirname + '/schema.sql', 'utf8');
conn._db.exec(schema, function(err){
    if (err)
        console.error('- Error initializing database: ' + err.message);
    else
    {
        console.log('- Database ready!');
        app.listen(8080, function(){
            console.log('- Listening on port 8080');
        });
    }
});
