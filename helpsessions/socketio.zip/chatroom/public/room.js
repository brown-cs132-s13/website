/*
    Chatroom: CS132 Project Implementation
    by Matt Patenaude
*/

/* Global variables */
var LAST_MESSAGE_ID = -1;
var POLL_INTERVAL = 5000;
var MY_MESSAGES = [];

/* Meta tag function (from handout) */
function meta(name) {
    var tag = document.querySelector('meta[name=' + name + ']');
    if (tag != null)
        return tag.content;
    return '';
}

/* Request function (modified from BieberFeed) */
function request(method, url, body, callback) {
    var req = new XMLHttpRequest();
    req.open(method, url, true);
    req.addEventListener('load', function(){
        callback(req, req.responseText);
    }, false);
    req.send(body);
}

/* Code run on page load */
var socket = null;
function init() {
    /* add a handler to the message submission form */
    var messageForm = document.getElementById('messageForm');
    messageForm.addEventListener('submit', messageFormSubmitted, false);
    
    /* set nickname */
    var nickname = prompt('What is your nickname?');
    document.getElementById('nicknameField').value = nickname;
    
    /* start polling for messages */
    setInterval(function(){
        var url = '/' + meta('roomName') + '/messages';
        if (LAST_MESSAGE_ID > -1)
            url += '/since/' + LAST_MESSAGE_ID;
        
        request('GET', url, null, messagePollHandler);
    }, POLL_INTERVAL);
    
    /* do an initial fetch */
    request('GET', '/' + meta('roomName') + '/messages', null, messagePollHandler);
    
    /* focus on the text field */
    document.getElementById('messageField').focus();
}
window.addEventListener('load', init, false);

/* DOM event handlers */
function messageFormSubmitted(e) {
    e.preventDefault();
    
    /* get our message information */
    var fd = new FormData(document.getElementById('messageForm'));
    var message = document.getElementById('messageField').value;
    
    /* send it */
    messageSending();
    request('POST', '/' + meta('roomName') + '/messages', fd, function(req, res){
        messageSent(parseInt(res, 10), message);
    });
}
function messagePollHandler(req, res) {
    var incomingMessages = JSON.parse(res);
    for (var i = 0; i < incomingMessages.length; i++)
        messageReceived(incomingMessages[i].id, incomingMessages[i].nickname, incomingMessages[i].body, new Date(incomingMessages[i].time * 1000));
}
function buildMessageElement(classname, nickname, message, time) {
    var h = time.getHours();
    var ampm = (h >= 12) ? 'pm' : 'am';
    h = h % 12;
    
    if (h == 0)
        h = 12;
    
    var m = ((time.getMinutes() < 10) ? '0' : '') + time.getMinutes();
    var timeString = h + ':' + m + ampm;
    
    var li = document.createElement('li');
    li.className = classname;
    
    var body = document.createElement('div');
    body.className = 'body';
    
    var background = document.createElement('div');
    background.className = 'background';
    
    var text = document.createElement('div');
    text.className = 'text';
    text.innerHTML = message;
    
    body.appendChild(background);
    body.appendChild(text);
    
    var summary = document.createElement('div');
    summary.className = 'summary embossed';
    summary.innerHTML = '<strong>' + nickname + '</strong> at ' + timeString;
    
    li.appendChild(body);
    li.appendChild(summary);
    
    return li;
}

/* Chatroom event handlers */
function messageReceived(id, nickname, message, time) {
    LAST_MESSAGE_ID = Math.max(LAST_MESSAGE_ID, id);
    
    /* if this is one of my own messages, bail */
    if (MY_MESSAGES.indexOf(id) > -1)
        return;
    
    /* create an element */
    var el = buildMessageElement('user', nickname, message, time);
    
    /* append it */
    var messageView = document.getElementById('messages');
    messageView.appendChild(el);
    
    var container = document.getElementById('messagesContainer');
    container.scrollTop = container.scrollHeight;
}
function messageSending() {
    var messageField = document.getElementById('messageField');
    messageField.disabled = true;
}
function messageSent(id, message) {
    /* keep track of my messages */
    MY_MESSAGES.push(id);
    
    /* clear the message field */
    var messageField = document.getElementById('messageField');
    messageField.value = '';
    messageField.disabled = false;
    
    /* add it to the list view */
    var messageView = document.getElementById('messages');
    var el = buildMessageElement('me', document.getElementById('nicknameField').value, message, new Date());
    messageView.appendChild(el);
    
    var container = document.getElementById('messagesContainer');
    container.scrollTop = container.scrollHeight;
}
