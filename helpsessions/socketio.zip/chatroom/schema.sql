DROP TABLE IF EXISTS messages;
CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room TEXT,
    nickname TEXT,
    body TEXT,
    time INTEGER
);
