// A simple example
var fs = require('fs');

var fileRead = false;
var startTime = Date.now();
var stopTime = null;
fs.readFile('bigfile.dat', function(err, data) {
    fileRead = true;
    stopTime = Date.now();
});

// count up
var count = 0;
function countUp() {
    count++;
    console.log('Counted to ' + count);
    
    if (!fileRead)
        process.nextTick(countUp);
    else
        console.log('File read in ' + (stopTime - startTime) + 'ms!');
}

countUp();
