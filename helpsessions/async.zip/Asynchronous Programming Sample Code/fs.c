/*
    fs.c
    Reimplementation of Node's fs.readFile(...) method using GCD.
*/

#include "fs.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <dispatch/dispatch.h>
#include <stdlib.h>

void fs_readFile(const char *filename, void (^callback)(my_bool err, void *buffer))
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        int fd = open(filename, O_RDONLY);
    
        struct stat fileInfo;
        fstat(fd, &fileInfo);
    
        void *buffer = malloc(fileInfo.st_size);
    
        size_t bytesRead = 0;
        while (bytesRead < fileInfo.st_size)
            bytesRead += read(fd, buffer + bytesRead, fileInfo.st_size - bytesRead);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            callback(0, buffer);
        });
    });
}
