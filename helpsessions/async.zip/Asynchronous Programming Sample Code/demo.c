/*
    A recreation of our JavaScript demo in C, using Blocks and GCD.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dispatch/dispatch.h>
#include "fs.h"

int main(int argc, char **argv)
{
    __block my_bool fileRead = 0;
    clock_t startTime = clock();
    __block clock_t stopTime = 0;
    
    fs_readFile("bigfile.dat", ^(my_bool err, void *buffer){
        fileRead = 1;
        stopTime = clock();
        free(buffer);
    });
    
    // count up
    __block unsigned long long count = 0;
    __block void (^countUp)(void) = ^{
        count++;
        fprintf(stderr, "Counted to %llu\n", count);
        
        if (!fileRead)
            dispatch_async(dispatch_get_main_queue(), countUp);
        else
        {
            fprintf(stderr, "File read in %lums!\n", (stopTime - startTime) / (CLOCKS_PER_SEC / 1000));
            exit(0);
        }
    };
    
    dispatch_async(dispatch_get_main_queue(), countUp);
    dispatch_main();
    return 0;
}
