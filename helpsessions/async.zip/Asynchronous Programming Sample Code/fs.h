/*
    fs.h
    Reimplementation of Node's fs.readFile(...) method using GCD.
*/

#ifndef __FS_H__
#define __FS_H__

typedef signed char my_bool;

void fs_readFile(const char *filename, void (^callback)(my_bool err, void *buffer));

#endif
